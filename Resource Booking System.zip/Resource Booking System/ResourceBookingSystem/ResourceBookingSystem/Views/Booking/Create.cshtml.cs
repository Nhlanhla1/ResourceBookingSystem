using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ResourceBookingSystem.Views.Booking
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
