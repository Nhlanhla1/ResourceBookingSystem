using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ResourceBookingSystem.Views.Booking
{
    public class UpcomingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
