using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ResourceBookingSystem.Views.Resource
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
