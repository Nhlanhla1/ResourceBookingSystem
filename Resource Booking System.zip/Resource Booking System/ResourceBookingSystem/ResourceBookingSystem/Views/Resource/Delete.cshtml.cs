using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ResourceBookingSystem.Views.Resource
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
